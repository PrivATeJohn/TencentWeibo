/** Automatically generated file. DO NOT MODIFY */
package com.example.Test_Terminal;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}