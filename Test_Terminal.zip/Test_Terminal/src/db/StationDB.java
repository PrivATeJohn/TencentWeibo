//2014.01.10---
package db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class StationDB extends SQLiteOpenHelper {
	//-------
	private Station station = new Station();
	// **
	private final static String DATABASE_NAME = "Terminal.db";
	private final static int DATABASE_VERSION = 1;
	// gps_table----
	
	private final static String TABLE_NAME = "Station_Table";
	// ---gps_table
	public final static String STATION_ID = "station_id";
	public final static String GPS_X = "station_x";
	public final static String GPS_Y = "station_y";
	public final static String GPS_A = "station_a";
	public final static String NAME = "name";
	public final static String TYPE = "type";

	public StationDB(Context context) {
		super(context, DATABASE_NAME, null, DATABASE_VERSION);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		// TODO Auto-generated method stub
		// ----create
		String sql = "CREATE TABLE " + TABLE_NAME + " (" + STATION_ID
				+ " INTEGER primary key autoincrement, " + GPS_X + " double," + GPS_Y
				+ " double,"+ GPS_A + " double,"+ NAME + " TEXT,"+ TYPE + " INTEGER " + ");";
		db.execSQL(sql);
}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		// TODO Auto-generated method stub
		//---delete table
		String sqll = "DROP TABLE IF EXISTS " + TABLE_NAME;
		db.execSQL(sqll);
		// ----create
		String sql = "CREATE TABLE " + TABLE_NAME + " (" + STATION_ID
				+ " INTEGER primary key , " + GPS_X + " double," + GPS_Y
				+ " double,"+ GPS_A + " double,"+ NAME + " TEXT,"+ TYPE + " INTEGER," + ");";
		db.execSQL(sql);
	}

	@Override
	public synchronized void close() {
		// TODO Auto-generated method stub
		super.close();
	}

	@Override
	public void onOpen(SQLiteDatabase db) {
		// TODO Auto-generated method stub
		super.onOpen(db);

	}
	// ----
	public Cursor select() {
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cursor = db
				.query(TABLE_NAME, null, null, null, null, null, null);
		return cursor;
	}

	// ----add
	public long insert(int id, double gps_x, double gps_y, double gps_a, String name, int type) {
		SQLiteDatabase db = this.getWritableDatabase();
		/* ContentValues */
		ContentValues cv = new ContentValues();
		cv.put(STATION_ID, id);
		cv.put(GPS_X, gps_x);
		cv.put(GPS_Y, gps_y);
		cv.put(GPS_A, gps_a);
		cv.put(NAME, name);
		cv.put(TYPE, type);
		long row = db.insert(TABLE_NAME, null, cv);
		return row;
	}

	// ----delete
	public void delete(int id) {
		SQLiteDatabase db = this.getWritableDatabase();
		String where = STATION_ID + "= ?";
		String[] whereValue = { Integer.toString(id) };
		db.delete(TABLE_NAME, where, whereValue);
	}
	
	// ----update
	public void update(int id, int type) {
		SQLiteDatabase db = this.getWritableDatabase();
		String where = STATION_ID + "= ?";
		String[] whereValue = { Integer.toString(id) };
		/* ContentValues */
		ContentValues cv = new ContentValues();
		cv.put(TYPE, type);
		db.update(TABLE_NAME, cv, where, whereValue);
	}
	//初始化数据库
	public void Initialization()
	{	
		//删除数据
		this.delete(1);
		this.delete(2);
		this.delete(3);
		this.delete(4);
		this.delete(5);
		//插入数据
		this.insert(1, station.x001, station.y001, 0, station.name001, 0);
		this.insert(2, station.x002, station.y002, 0, station.name002, 0);
		this.insert(3, station.x003, station.y003, 0, station.name003, 0);
		this.insert(4, station.x004, station.y004, 0, station.name004, 0);
		this.insert(5, station.x005, station.y005, 0, station.name005, 0);
		
	}

}
