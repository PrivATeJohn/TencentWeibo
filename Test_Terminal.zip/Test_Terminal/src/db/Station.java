package db;
//
//------------------------------------------------------------------
//station_id	station_x	station_y	station_a	name	type
//------------------------------------------------------------------
//INTEGER		float		float		float		TEXT	INTEGER
//------------------------------------------------------------------
//type == 0	未到达
//type == 1	进入站点70M
//type == 2 站点中30M
//type == 3 离开站点
//
public class Station {
	// ------
	// 001站
	final public double x001 = 122.143875;
	final public double y001 = 37.4306;
	final public String name001 = "华夏集团";
	// 002站
	final public double x002 = 122.143036;
	final public double y002 = 37.433445;
	final public String name002 = "世纪大厦";
	// 003站
	final public double x003 = 122.141426;
	final public double y003 = 37.440044;
	final public String name003 = "锦绣北山小区（长峰）";
	// 004站
	final public double x004 = 122.14087;
	final public double y004 = 37.444122;
	final public String name004 = "长峰北";
	// 005站
	final public double x005 = 122.1391;
	final public double y005 = 37.45149;
	final public String name005 = "望岛（山水家园）";

}
