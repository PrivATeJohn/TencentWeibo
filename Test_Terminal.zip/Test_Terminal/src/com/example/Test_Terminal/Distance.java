//经纬度转化成距离
//2014.02.13
package com.example.Test_Terminal;

public class Distance {
	//Lat1 Lng1 表示A点经纬度，Lat2 Lng2 表示B点经纬度；
	///a=Lat1 – Lat2 为两点纬度之差 b=Lng1 -Lng2 为两点经度之差；
	//6378137.0为地球半径，单位为米；
	//计算出来的结果单位为米。
	private static double EARTH_RADIUS = 6378137.0;
	private static double rad(double d)
	{
	   return d * Math.PI / 180.0;
	}

	public static double GetDistance(double lat1, double lng1, double lat2, double lng2)
	{
	   double radLat1 = rad(lat1);
	   double radLat2 = rad(lat2);
	   double a = radLat1 - radLat2;
	   double b = rad(lng1) - rad(lng2);
	   double s = 2 * Math.asin(Math.sqrt(Math.pow(Math.sin(a/2),2) + 
	    Math.cos(radLat1)*Math.cos(radLat2)*Math.pow(Math.sin(b/2),2)));
	   s = s * EARTH_RADIUS;
	   s = Math.round(s * 10000) / 10000;
	   return s;
	}
}
