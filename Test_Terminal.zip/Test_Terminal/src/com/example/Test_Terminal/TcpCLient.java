//2013.11.19
package com.example.Test_Terminal;

import java.io.OutputStreamWriter;
import java.net.Socket;

//设置发送字符串
public class TcpCLient {
	// **设置变量
	private Socket socket = null;

	public void sendMessage(String str) {
		try {
			// 新建一个socket
			socket = new Socket(new Constant().ip, new Constant().port);
			System.out.println("socket:" + socket.toString());
			// 输出流，发送到服务器端
			//DataOutputStream outputStream = new DataOutputStream(socket.getOutputStream());
			OutputStreamWriter outputStream = new OutputStreamWriter(socket.getOutputStream(),"UTF-8");
			outputStream.write(str);
			// 强制输出，清空缓冲区数据
			outputStream.flush();
			socket.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}