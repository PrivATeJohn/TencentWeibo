//2013.11.19---------主要界面处理----------
//**程序每隔500ms比较一次数据
package com.example.Test_Terminal;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import com.example.Test_Terminal.R;
import db.StationDB;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

	// **设置变量----------
	private Constant constant = new Constant();
	private boolean runFlag = false; // running->true; stop->false
	private TextView tipTextView = null;
	private TextView gpsTextView = null; // GPS information
	private TextView stationTextView = null; // station information
	private TextView timeTextView = null; // time information
	private TextView infoTextView = null; // information
	private String information = "--------------------------" + "\r\n";
	
	private Button myButton = null; // button01
	private Handler handler = null; // handler,TCP
	private Handler chandler = null; // chandler,Compare
	// **计时器设置
	private Timer timer;
	// XML字符串
	private String xml = null;
	private LocationManager locationManager = null;
	private String provider = null;
	// XY坐标
	private double x = 0;
	private double y = 0;
	// DB
	private StationDB mStationDB;	//数据库
	private Cursor mCursor;			//游标
	private String startStation;	//起始站点
	private String endStation;		//终点站
	//XML文件flag格式
	private int startFlag = constant.startFlag;	//开始，起始站点信息
	private int endFlag = constant.endFlag;		//结束站点信息
	private int enterFlag = constant.enterFlag;	//进入站点信息
	private int leaveFlag = constant.leaveFlag;	//离开站点信息
	@SuppressLint("SimpleDateFormat")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		//main thread
		System.out.println("+++Main+++ Thread's id :" + Thread.currentThread().getId());
		
		// *******GPS-----
		locationManager = (LocationManager) MainActivity.this.getSystemService(Context.LOCATION_SERVICE);
		System.out.println("locationManager: " + locationManager.toString());
		//--------------*_*-----^_^---------------
		provider = BestProvider();
		if (provider != null) {			// ****GPS_PROVIDER NETWORK_PROVIDER
			locationManager.requestLocationUpdates(provider,
					new Constant().minTime, new Constant().minDistance,
									TestLocationListener);
		} 
		else {
			System.out.println("无法获取恰当的Provider");
			Toast.makeText(MainActivity.this, "请确保网络连接并打开GPS", Toast.LENGTH_SHORT).show();
		}
		//初始化
		Initialization();
		// time/daemon守护线程
		//test TCP 
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");	//设置日期格式,获取系统时间
		xml= new Xml().createXML(-1, 11, 11, x, y, "客户端打开程序", 1, df.format(new Date()));
		handler.post(new TcpRunnable());

		
	}
	private void Initialization(){
		// ^_^通过Handler和Looper解决线程问题，确定线程ID^_^-------
		HandlerThread handlerThread = new HandlerThread("myHandlerThread");//TCP线程
		handlerThread.start();
		HandlerThread chandlerThread = new HandlerThread("cHandlerThread");//Compare线程
		chandlerThread.start();
		// ^_^通过getLooper方法获取一个Looper对象控制句柄，将这个Looper对象映射到一个Handler中去来实现一个线程同步机制
		handler = new Handler(handlerThread.getLooper());
		chandler =  new Handler(chandlerThread.getLooper());
		// **获取TextView及Button并进行设置------------------
		tipTextView = (TextView) findViewById(R.id.tipTextView);
		gpsTextView = (TextView) findViewById(R.id.gpsTextView);
		stationTextView = (TextView) findViewById(R.id.stationTextView);
		timeTextView = (TextView) findViewById(R.id.timeTextView);
		infoTextView = (TextView) findViewById(R.id.infoTextView);
		myButton = (Button) findViewById(R.id.myButton);	//获取myButton对象并设置监听类,sending或者停止send
		myButton.setOnClickListener(new MyButtonListenter());
		// **DB
		mStationDB = new StationDB(this);
		mStationDB.Initialization();	//初始化数据库
		getRouteInfo();		//获取起始站点信息
		
		// **android界面显示-------------------
		stationTextView.setText("Waiting for station info...."+ "\r\n" + " ");
	}
//Button监听内部类
	//$$myButton监听类
	private class MyButtonListenter implements OnClickListener {
		@SuppressLint("SimpleDateFormat")
		@Override
		public void onClick(View arg0) {
			// TODO Auto-generated method stub
			if(runFlag == false){	//当前未运行
				//运行程序
				runFlag = true;
				tipTextView.setText("Status: Runing...." );
				myButton.setText("Click to exit the program");
				stationTextView.setText("FROM：  "+ startStation + "\r\n" + "TO:  " + endStation + "\r\n");
				Toast.makeText(MainActivity.this, "--开始行车测试--", Toast.LENGTH_SHORT).show();
				chandler.post(new timeRunnable());
			}
			else{
				runFlag = false;
				//程序结束
				System.exit(0);
			}
		}
	}

	// $$获取最恰当的provider
	private String BestProvider() {
		// 生成一个Criteria对象
		Criteria criteria = new Criteria();
		// 设置查询条件
		criteria.setAccuracy(Criteria.ACCURACY_FINE);
		criteria.setPowerRequirement(Criteria.POWER_LOW);
		criteria.setAltitudeRequired(false);
		criteria.setSpeedRequired(false);
		criteria.setCostAllowed(false);
		String provider = locationManager.getBestProvider(criteria, true);
		// 设置为true则说明可用时才比较（机器打开该获取方式），false则不判断是否可用
		System.out.println("Best provider ---->" + provider);
		return provider;
	}
// 获取位置信息
	// $$LocationManager的监听器--------------
	private final LocationListener TestLocationListener = new LocationListener() {
		@Override
		public void onStatusChanged(String provider, int status, Bundle extras) {
			// TODO Auto-generated method stub
		}
		@Override
		public void onProviderEnabled(String provider) {
			// TODO Auto-generated method stub
		}
		@Override
		public void onProviderDisabled(String provider) {
			// TODO Auto-generated method stub
		}
		@Override
		public void onLocationChanged(Location location) {
			// TODO Auto-generated method stub
			// ---------更新位置信息
			updateLocation(location);
		}
	};	
	// 获取用户位置函数
	private void updateLocation(Location location) {
		if (location != null) {
			x = (double) location.getLongitude();
			y = (double) location.getLatitude();
			System.out.println(location.getLongitude() + "-----" + location.getLatitude());
			gpsTextView.setText("X坐标：" + x + "\r\n" + "Y坐标：" +y + "\r\n" + "--------------------------");
		} else
			System.out.println("Can't get the location!!!!");
	}

// TCP数据传输
	// $$实现runnable接口来实现--TCP--多线程
	private class TcpRunnable implements Runnable {
		@Override
		public void run() {
			// TODO Auto-generated method stub
			System.out.println("+++Tcp+++ Thread's id :" + Thread.currentThread().getId());
			// **传送数据------------
			TcpCLient tcpCLient = new TcpCLient();
			// **发送数据--------------
			tcpCLient.sendMessage(xml);
		}
	}
// 计时器,一直循环运行
	// $$实例化一个TimerTask，为Timer提供定时执行的内容----
	TimerTask task = new TimerTask(){
		@Override
		public void run() {
			// TODO Auto-generated method stub
			//……………………在主线程中更新时间
			MainActivity.this.runOnUiThread(new Runnable() {
				@SuppressLint("SimpleDateFormat") public void run() {
					SimpleDateFormat dff = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");	//设置日期格式,获取系统时间
					timeTextView.setText( "系统时间： "+ dff.format(new Date()) );
				}
			});
			//比较
			Compare();
		}
	};

	// $$实现runnable接口来实现--计时--多线程
	private class timeRunnable implements Runnable {
		@Override
		public void run() {
			// TODO Auto-generated method stub
			System.out.println("+++TIME+++ Thread's id :"+ Thread.currentThread().getId());
			timer = new Timer(true);//是否为daemon守护线程
			timer.schedule(task, 0, 500);//task,delay延迟, period多久执行一次
			//timer.cancel();
		}
	}
	
//获取起始站点和终点站信息
	private void getRouteInfo(){
		mCursor = mStationDB.select();
		mCursor.moveToPosition(0);
		startStation = mCursor.getString(4);	//起始站点
		mCursor.moveToPosition(4);
		endStation = mCursor.getString(4);	//终点站
	}

//判断比较到站信息,一直循环运行
//***游标里面都是从0开始，数据库里面从1开始
	private void Compare(){
		//----循环判断知道行程结束
		mCursor= mStationDB.select();	//每次查询完成更换一个新的游标
		for(int i = 0; i < mCursor.getCount(); i ++){
			mCursor.moveToPosition(i);
			//^_^公交车未到达该站点 <<<<<<<<<<<<<<<<<<<70-------------
			if(mCursor.getInt(5) == 0){		
				double distance = Distance.GetDistance(x, y, mCursor.getDouble(1), mCursor.getDouble(2));
				final String stationStr = mCursor.getString(4);
				//小于进入站点的距离，所以进入站点
				if(distance < constant.enterMeter){ 	
					//如果为起始站点
					if(mCursor.getInt(0) == 1){		
						//显示信息
						final String str = "起始站点-->" + stationStr;
						operation(startFlag, stationStr, stationStr, str, i, 1);
					}
					//如果为中间站点
					else{
						final String str = "车辆进站-->" + stationStr;
						operation(enterFlag, stationStr, stationStr, str, i, 1);
					}
				}
			}
			//^_^车辆已经进站 <<<<<<<<<70------30>>>>>>>>>>>
			else if(mCursor.getInt(5) == 1){		
				double distance = Distance.GetDistance(x, y, mCursor.getDouble(1), mCursor.getDouble(2));
				final String stationStr = mCursor.getString(4);
				//正在站点中
				if(distance < constant.leaveMeter){ 
					//如果为终站点
					if(mCursor.getInt(0) == 5){		
						final String str = "--行车结束--终点站：" + stationStr;
						operation(endFlag, stationStr, stationStr, str, i, 3);
					}
					//如果为中间站点或者起始站点
					else{				
						mStationDB.update(i+1, 2);
					}
					
				}
			}
			//^_^公交车到达站点>>>>>>>>>>>>>>>30----------
			else if(mCursor.getInt(5) == 2){		
				double distance = Distance.GetDistance(x, y, mCursor.getDouble(1), mCursor.getDouble(2));
				final String stationStr = mCursor.getString(4);
				if(distance > constant.leaveMeter){ 	//小于离开站点的距离，并且type为1，说明进入过该站台，所以离开站点
					//当前只可能是中间站点
					final String str = "车辆离站-->" + stationStr;
					operation(leaveFlag, stationStr, "行进中....",  str, i, 3);
				}
			}
			//^_^公交车离开该站点
			else if(mCursor.getInt(5) == 3){		
				//To do nothing
			}
		}
		//for 循环之外
		mCursor.close();	//释放游标
	}
	@SuppressLint("SimpleDateFormat")
	//发送数据，修改数据库，并在主线程提示toast
	public void operation(int flag, final String stationStr,final String nowStr,  final String toastStr, int i, int type){
		SimpleDateFormat df = new SimpleDateFormat("HH:mm:ss");	//设置日期格式,获取系统时间
		//设置information
		information = information + "->" + toastStr + df.format(new Date()) + "\r\n";
		//……………………在主线程UI中显示toast
		MainActivity.this.runOnUiThread(new Runnable() {
			@Override
			public void run() {
				Toast.makeText(MainActivity.this, toastStr, Toast.LENGTH_SHORT).show();
				stationTextView.setText("FROM：  "+ startStation + "\r\n" + "TO:  " + endStation + "\r\n" + "NOW:  " + nowStr);
				infoTextView.setText(information);
			}
		});
		//发送起始站点TCP
		xml= new Xml().createXML(flag, 11, 11, x, y, toastStr, 1, df.format(new Date()));
		handler.post(new TcpRunnable());
		//更改数据库信息正在该站点
		mStationDB.update(i+1, type);

		System.out.println(toastStr);
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
}
