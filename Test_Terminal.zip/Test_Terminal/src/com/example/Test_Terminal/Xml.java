//2013.11.19--------XML操作-----------------
package com.example.Test_Terminal;
//--------------------------------------------------------------
//sign	number	route	x		y		text		version
//int	int		int		double	double	String		int
//标志	车辆号码	路线		x坐标		y坐标		（信息）站点名	软件版本号
//--------------------------------------------------------------
public class Xml {
	//##创建XML------------
	public String createXML(int sign,int number, int route, double x, double y, String text, int version, String time){
		String str = "<?xml version="+"\"1.0\""+" encoding="+"\"utf-8\""+"?>"
				+ "<userdata>"
				+ "<sign>" + sign + "</sign>"
				+ "<number>" + number + "</number>"
				+ "<route>" + route + "</route>"
				+ "<x>" + x + "</x>"
				+ "<y>" + y + "</y>"
				+ "<text>" + text + "</text>"
				+ "<version>" + version + "</version>"
				+ "<time>" + time + "</time>"
				+ "</userdata>";
		return str;
	}
		
	//-----------
}
