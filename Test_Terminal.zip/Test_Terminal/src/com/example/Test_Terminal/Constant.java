//2013.11.22----------常量设定-------------
package com.example.Test_Terminal;

public class Constant {
	// 主要固定常量
	final public String ip = "127.0.0.1";// 服务器IP-----------60.217.65.58 //主机IP： 10.0.2.2 
	final public int port = 4788;// 通信TCP端口
	final public int minTime = 0;// GPS最小改变时间单位是毫秒，两次更新最短时间（最少）
	final public float minDistance = 0;// GPS最小改变距离，单位为米
	//final public int realTime = 5; //实时信息反馈，每realTime秒发送一次数据
	//XML文件flag格式
	final public int flag = 0;	//正常行驶状态
	final public int startFlag = 1;	//开始，起始站点信息
	final public int endFlag = 2;	//结束站点信息
	final public int enterFlag = 3;	//进入站点信息
	final public int leaveFlag = 4;	//离开站点信息
	//进出站距离
	final public int enterMeter = 70;	//规定70
	final public int leaveMeter = 30;	//规定70
	
}
